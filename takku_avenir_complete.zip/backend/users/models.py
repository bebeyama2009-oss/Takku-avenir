from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    """Custom User model for TAKKU AVENIR"""
    
    GRADE_CHOICES = [
        ('SECONDE', 'Seconde'),
        ('PREMIERE', 'Première'),
        ('TERMINALE', 'Terminale'),
    ]
    
    SERIES_CHOICES = [
        ('S', 'Série S'),
        ('L', 'Série L'),
        ('L2', "Série L'"),
        ('G', 'Série G'),
    ]
    
    ROLE_CHOICES = [
        ('STUDENT', 'Élève'),
        ('TEACHER', 'Enseignant'),
        ('ALUMNI', 'Ancien élève'),
        ('ADMIN', 'Administrateur'),
    ]
    
    phone = models.CharField(max_length=20, blank=True)
    school = models.CharField(max_length=200, default='Lycée Galandou Diouf')
    grade = models.CharField(max_length=20, choices=GRADE_CHOICES, blank=True)
    series = models.CharField(max_length=10, choices=SERIES_CHOICES, blank=True)
    interests = models.JSONField(default=list, blank=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='STUDENT')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.get_full_name()} - {self.school}"
