from django.db import models
from django.conf import settings

class OrientationTest(models.Model):
    """Orientation test model"""
    
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, 
                            related_name='orientation_tests')
    test_date = models.DateTimeField(auto_now_add=True)
    answers = models.JSONField(help_text="Réponses au questionnaire")
    
    # Résultats
    recommended_fields = models.JSONField(help_text="Filières recommandées avec scores")
    compatibility_scores = models.JSONField(help_text="Scores de compatibilité par domaine")
    
    completed = models.BooleanField(default=False)
    
    class Meta:
        ordering = ['-test_date']
        verbose_name = "Test d'orientation"
        verbose_name_plural = "Tests d'orientation"
    
    def __str__(self):
        return f"{self.user.username} - {self.test_date.strftime('%d/%m/%Y')}"


class Question(models.Model):
    """Question model for orientation test"""
    
    SECTION_CHOICES = [
        ('ACADEMIC', 'Profil académique'),
        ('INTERESTS', "Centres d'intérêt"),
        ('ASPIRATIONS', 'Aspirations professionnelles'),
    ]
    
    TYPE_CHOICES = [
        ('SINGLE', 'Choix unique'),
        ('MULTIPLE', 'Choix multiples'),
        ('SCALE', 'Échelle'),
    ]
    
    section = models.CharField(max_length=20, choices=SECTION_CHOICES)
    question_text = models.TextField()
    question_type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    order = models.IntegerField(default=0)
    
    # Options de réponse (JSON)
    options = models.JSONField(help_text="Liste des options de réponse")
    
    # Pondération pour l'algorithme
    weight = models.IntegerField(default=1)
    category_mapping = models.JSONField(help_text="Mapping réponse -> catégorie de métier")
    
    is_active = models.BooleanField(default=True)
    
    class Meta:
        ordering = ['section', 'order']
        verbose_name = 'Question'
        verbose_name_plural = 'Questions'
    
    def __str__(self):
        return f"{self.get_section_display()} - Q{self.order}"
