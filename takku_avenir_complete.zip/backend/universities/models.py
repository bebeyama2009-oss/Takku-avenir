from django.db import models

class University(models.Model):
    """University model"""
    
    TYPE_CHOICES = [
        ('PUBLIC', 'Publique'),
        ('PRIVATE', 'Privée'),
    ]
    
    CITY_CHOICES = [
        ('DAKAR', 'Dakar'),
        ('SAINT_LOUIS', 'Saint-Louis'),
        ('BAMBEY', 'Bambey'),
        ('ZIGUINCHOR', 'Ziguinchor'),
        ('THIES', 'Thiès'),
        ('AUTRE', 'Autre'),
    ]
    
    name = models.CharField(max_length=200)
    short_name = models.CharField(max_length=50, help_text="Ex: UCAD, UGB")
    type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    city = models.CharField(max_length=50, choices=CITY_CHOICES)
    website = models.URLField(blank=True)
    description = models.TextField()
    logo = models.ImageField(upload_to='universities/', blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)
    
    class Meta:
        ordering = ['name']
        verbose_name = 'Université'
        verbose_name_plural = 'Universités'
    
    def __str__(self):
        return f"{self.short_name} - {self.name}"


class Field(models.Model):
    """Field/Filière model"""
    
    DURATION_CHOICES = [
        ('2', 'Bac+2'),
        ('3', 'Licence (Bac+3)'),
        ('5', 'Master (Bac+5)'),
        ('8', 'Doctorat (Bac+8)'),
    ]
    
    name = models.CharField(max_length=200)
    university = models.ForeignKey(University, on_delete=models.CASCADE, related_name='fields')
    duration = models.CharField(max_length=10, choices=DURATION_CHOICES)
    
    required_series = models.JSONField(default=list, help_text="Séries acceptées: S, L, G")
    required_average = models.DecimalField(max_digits=4, decimal_places=2, null=True, blank=True, 
                                          help_text="Moyenne minimale requise")
    
    tuition_fees = models.IntegerField(help_text="Frais de scolarité annuels en FCFA", default=0)
    scholarships_available = models.BooleanField(default=False)
    
    description = models.TextField()
    job_prospects = models.TextField(help_text="Débouchés professionnels")
    insertion_rate = models.IntegerField(null=True, blank=True, 
                                        help_text="Taux d'insertion professionnelle en %")
    
    related_careers = models.ManyToManyField('careers.Career', blank=True, 
                                            related_name='related_fields')
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)
    
    class Meta:
        ordering = ['university', 'name']
        verbose_name = 'Filière'
        verbose_name_plural = 'Filières'
    
    def __str__(self):
        return f"{self.name} - {self.university.short_name}"
